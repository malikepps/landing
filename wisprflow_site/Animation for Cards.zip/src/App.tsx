import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import PricingCard from "./components/PricingCard";

const pricingPlans = [
  {
    id: 1,
    title: "✨️ Champion ✨",
    price: 30,
    period: "mo.",
    benefit: "Buy 30 books for our kids!",
    buttonColor: "#15857a"
  },
  {
    id: 2,
    title: "🌟 Hero 🌟",
    price: 50,
    period: "mo.",
    benefit: "Buy 50 books for our kids!",
    buttonColor: "#d97706"
  },
  {
    id: 3,
    title: "💎 Legend 💎",
    price: 100,
    period: "mo.",
    benefit: "Fund 100 learning supplies!",
    buttonColor: "#7c3aed"
  }
];

export default function App() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setDirection(1);
      setCurrentIndex((prev) => (prev + 1) % pricingPlans.length);
    }, 4000);

    return () => clearInterval(timer);
  }, []);

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  const paginate = (newDirection: number) => {
    setDirection(newDirection);
    setCurrentIndex((prev) => {
      const nextIndex = prev + newDirection;
      if (nextIndex < 0) return pricingPlans.length - 1;
      if (nextIndex >= pricingPlans.length) return 0;
      return nextIndex;
    });
  };

  return (
    <div className="relative w-[516px] h-[450px]">
      <AnimatePresence initial={false} custom={direction}>
        <motion.div
          key={currentIndex}
          custom={direction}
          variants={slideVariants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 }
          }}
          className="absolute w-full h-full"
        >
          <PricingCard {...pricingPlans[currentIndex]} />
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
