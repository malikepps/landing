
  # Lottie Animation for Cards

  This is a code bundle for Lottie Animation for Cards. The original project is available at https://www.figma.com/design/FkJ3Jdgpzb3UbiAtKg8fhi/Lottie-Animation-for-Cards.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  